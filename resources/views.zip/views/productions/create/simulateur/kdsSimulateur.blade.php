@extends('layouts.main')

@section('content')

<style>
    .ribbon {
        position: relative;
        background: #11771f;
        color: white;
        padding: 10px;
        font-weight: bold;
        text-align: center;
        border-radius: 5px 5px 0 0;
    }

    .btn-inactif {
        background-color: #d9d9d9;
        color: #666;
        cursor: not-allowed;
        pointer-events: none;
    }
    
    .optional-garantie {
        background-color: #f8f9fa;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        border-left: 4px solid #6c757d;
    }
    
    .api-info {
        background-color: #e9ecef;
        padding: 10px;
        border-radius: 5px;
        margin-top: 10px;
        font-size: 0.9em;
    }
    
    .loading {
        color: #6c757d;
        font-style: italic;
    }
    
    .auto-update {
        border-left: 4px solid #0d6efd;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-8">
            <div class="card p-4 auto-update">
                <h4 class="text-center text-uppercase">Simulateur de prime</h4>
                <fieldset>
                    <legend class="text-center w-auto float-none px-2 "><small>Données de simulation</small></legend>
                
                    <form id="primeForm">
                        @csrf

                        <div class="form-group row">
                            <div class="col-sm-12 col-md-6 mb-3">
                                <label class="form-label">Code Produit :</label>
                                <input type="text" class="form-control" id="CodeProduit" name="CodeProduit" value="{{ $product->CodeProduit}}" required>
                            </div>
                            <div class="col-sm-12 col-md-6 mb-3">
                                <label class="form-label">Code Périodicité :</label>
                                <select name="codePeriodicite" id="codePeriodicite" class="form-control" required>
                                    <option value="M">MENSUEL</option>
                                    <option value="T">TRIMESTRIEL</option>
                                    <option value="S">SEMESTRIEL</option>
                                    <option value="A">ANNUEL</option>
                                </select>
                            </div>
                            <div class="col-sm-12 col-md-6 mb-3">
                                <label class="form-label">Prime souhaité :</label>
                                <select name="capitalSouscrit" id="capitalSouscrit" class="form-select" required>
                                    <option value="" selected>Selectionnez une prime</option>
                                    <option value="15000">15 000</option>
                                    <option value="20000">20 000</option>
                                    <option value="25000">25 000</option>
                                    <option value="30000">30 000</option>
                                    <option value="40000">40 000</option>
                                    <option value="50000">50 000</option>
                                    <option value="75000">75 000</option>
                                    <option value="100000">100 000</option>
                                </select>
                            </div>
                            <div class="col-sm-12 col-md-6 mb-3">
                                <label class="form-label">Date de naissance :</label>
                                <input type="Date" class="form-control" id="dateNaissance" name="dateNaissance" required>
                            </div>
                            <div class="col-sm-12 col-md-6 mb-3 d-none">
                                <label class="form-label">Âge Calculé :</label>
                                <input type="hidden" class="form-control" id="age" name="age">
                            </div>
                        </div>
                        
                        <!-- Section pour les garanties optionnelles -->
                        <div id="optionalGaranties" class="mt-4">
                            <h5 class="mb-3">Garanties optionnelles</h5>
                            <!-- Les garanties optionnelles seront ajoutées ici dynamiquement -->
                        </div>
                    </form>
                </fieldset>
            </div>
        </div>
        <div class="col-sm-12 col-md-4">
           <div class="card shadow-lg border-0 rounded-lg">
                <div class="card-header text-white text-center py-3">
                    <h5 class="text-uppercase mb-0">Résultat du simulateur</h5>
                </div>

                <div class="card-body">
                    <div class="container">
                        <table class="table table-bordered table-striped">
                            <thead class="table-light">
                                <tr>
                                    <th>Garantie</th>
                                    <th>Prime</th>
                                    <th>Capital</th>
                                </tr>
                            </thead>
                            <tbody id="result">
                                <!-- Les résultats seront affichés ici -->
                                <tr>
                                    <td colspan="3" class="text-center">Veuillez remplir les informations de simulation</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="ribbon">Prime Totale</div>

                        <table class="table">
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="2" class="text-end fw-bold">Montant Total :</td>
                                    <td id="primeTotal" class="fw-bold">0</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <a href="{{ route('prod.create',$product->CodeProduit) }}" id="btn-souscription" class="btn btn-primary btn btn-inactif">Souscrire</a>
            </div>
        </div>
    </div>
</div>

<script>
    const garanties = @json($productGarantie);
</script>
@endsection